const connection  = require('./db/db');
var AWS = require('aws-sdk');
AWS.config.update({
    accessKeyId: "AKIA4D6ZHYVB35PIIEVE",
    secretAccessKey: "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"    
});

var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: false });
const express = require('express');
var nodejs = express();

nodejs.set('view engine', 'ejs');

nodejs.get('/',function(req,res){        
    connection.query('SELECT * FROM customers ORDER BY id desc',function(err,result){ 
        if(err){        
         res.render('view',{data:''});   
        }else{                        
         res.render('view',{data:result});
        }                            
    });
});

nodejs.get('/add',function(req,res){        
    res.render('add', {name: '',email: ''})
});

nodejs.post('/add',urlencodedParser, function(req, res){ 
  var response = {  
        name:req.body.name,  
        email:req.body.email,
        file:req.body.file  
  };     
  var file = req.body.file;
  //For AWS store S3.
    var bucketName = 'sdk-bucket-node-test'; 
    var keyName = file;  
    var bucketPromise = new AWS.S3({apiVersion: '2006-03-01'}).createBucket({Bucket: bucketName}).promise();  
    bucketPromise.then(function(data) {
        var objectParams = {Bucket: bucketName, Key: keyName, Body: 'Hello World!'};     
        var uploadPromise = new AWS.S3({apiVersion: '2006-03-01'}).putObject(objectParams).promise();
        uploadPromise.then(function(data) {
            console.log("Successfully uploaded data to " + bucketName + "/" + keyName);
        });
    }).catch(function(err) {
        console.error(err, err.stack);
    });
  //For AWS store S3.
  connection.query('INSERT INTO customers SET ?', response, function(err, result){        
    if (err) {                                     
        throw err; 
    } else {                            
        res.redirect('/');
    }
  });
});

nodejs.get('/edit/(:id)',urlencodedParser,function(req,res){ 
    var uid = req.params.id.toString();       
    connection.query('SELECT * FROM customers WHERE id = ?', uid, function(err, result){        
        if (err) throw err;        
        res.render('edit', {name: result[0].name,email: result[0].email,id: result[0].id})    
    });     
});

nodejs.post('/update/(:id)',urlencodedParser,function(req,res){ 
    var uid = req.params.id.toString();           
    var name = req.body.name;
    var email = req.body.email;      
    connection.query('UPDATE customers SET name = ?, email = ? WHERE id= ?',[name,email, uid], function(err, result){                
        if (err) {                
            throw err;
        } else {                
            res.redirect('/')
        }
    });     
});

nodejs.get('/delete/(:id)',urlencodedParser, function(req, res) {
    var uid = req.params.id.toString();    
    connection.query('DELETE FROM customers WHERE id = ' + req.params.id, uid, function(err, result) {            
        if (err) {                
            res.redirect('/')
        } else {                
            res.redirect('/')
        }
    });
});

nodejs.listen(3333);
console.log("server start at port 3333");


// http.createServer(function (req, res) {
//     res.writeHead(200, {'Content-Type': 'text/html'}); // http header
//     // console.log(res);
//     var url = req.url;
//     if(url ==='/about'){
//         // res.sendFile('index.html');
//        res.write('<h1>about us page<h1>'); //write a response
//        res.end(); //end the response
//     }else if(url ==='/contact'){
//        res.write('<h1>contact us page<h1>'); //write a response
//        res.end(); //end the response
//     }else{
//        res.write('<h1>Hello World!<h1>'); //write a response
//        res.end(); //end the response
//     }}).listen(3333, function(){
//     console.log("server start at port 3333"); //the server object listens on port 3333
//    });


